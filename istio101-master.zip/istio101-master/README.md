# Istio 101

This is the repository for the [Istio][istio] 101 workshop from IBM.

- [presentation](./presentation) -- the data for the teacher/leader of the workshop
- [workshop](./workshop) -- the vanilla code for the code of the workshop


## License

See [LICENSE](./LICENSE) for license information.

[istio]: https://istio.io/
